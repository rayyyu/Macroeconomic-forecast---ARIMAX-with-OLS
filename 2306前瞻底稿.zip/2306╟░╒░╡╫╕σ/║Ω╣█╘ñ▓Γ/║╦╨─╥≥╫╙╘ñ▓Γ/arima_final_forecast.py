import pandas as pd
import numpy as np
from itertools import combinations
from sklearn.model_selection import TimeSeriesSplit
from tqdm import tqdm
import pmdarima as pm
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson
from statsmodels.tsa.stattools import adfuller


factor_number_ols = 3
factor_number_olsAR = 5
factor_number_arimax = 7
# 滚动窗口长度
window_length = 4
ols_saves = pd.ExcelWriter(r'C:\Users\Ray S Yu\Desktop\ForecastStream\ARIMA_forecast_core.xlsx')
dep_data = pd.read_excel('rolling_macro.xlsx', sheet_name="nonCore", index_col=0)
indept_data = pd.read_excel('rolling_macro.xlsx', sheet_name="Macro_Data", index_col=0)
dep_sh = pd.read_excel(r'C:\Users\Ray S Yu\Desktop\macro datasets\arima_input_srb.xlsx', sheet_name=0, index_col=0)
date = '2014-03-31'
dep_data_all = dep_data[dep_data.index >= date]
indept_data = indept_data.iloc[1:]
data = pd.concat([dep_sh, indept_data], axis=1)
list_y = dep_sh.columns

obs = np.sort(dep_data.iloc[1:].index.unique())
cv = TimeSeriesSplit(n_splits=window_length, test_size=4, gap=0)
score_total = []
variable_result = pd.DataFrame()
for i in tqdm(range(len(list_y)), ascii=True):
    tmp_model = pm.arima.ARIMA(order=(4, 0, 2), seasonal_order=(0, 0, 0, 0), suppress_warnings=True)
    tmp_fit = tmp_model.fit(dep_sh[list_y[i]])
    tmp_forecast = tmp_fit.predict(n_periods=2)
    tmp_forecast.reset_index(drop=True, inplace=True)
    variable_result = pd.concat([variable_result, tmp_forecast], axis=1, ignore_index=True)
    variable_result.reset_index(drop=True, inplace=True)
variable_result.columns = dep_sh.columns
variable_result.to_excel(ols_saves)
ols_saves.save()
print(obs)